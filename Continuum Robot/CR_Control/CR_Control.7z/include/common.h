
#include <vector>

extern std::vector<float> orb_position;
extern std::vector<float> orb_origin;
